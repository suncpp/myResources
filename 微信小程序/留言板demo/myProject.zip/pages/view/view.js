// page/view/view.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    insertTest:'',
    testList:[],
  },

  /**
   * 获取input值
   */
  bindinput:function(e){  
    this.setData({
      insertTest: e.detail.value,
    });
  },
  /*
  * add
  * 添加的方法
  */
  add:function(e){
    this.data.testList.unshift(this.data.insertTest);
    let list = this.data.testList;
    this.setData({
      testList:list,
      insertTest:''
    })
  },
  /**
   * delData 删除点击的数据
   */
  delData:function(e){
    this.data.testList.splice(e.currentTarget.dataset.index,1); 
    var list = this.data.testList;
    this.setData({
      testList:list,
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})