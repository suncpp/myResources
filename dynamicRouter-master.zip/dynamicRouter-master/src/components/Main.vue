<template>
	<section>
		<p class="message">页面展示</p>
	</section>
</template>

<script>
	export default {
		data(){
			return {
			}
		}
	}

</script>

<style scoped>
	.message{
		font-size: 18
	}
</style>